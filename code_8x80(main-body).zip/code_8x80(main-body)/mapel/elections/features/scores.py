#!/usr/bin/env python

import math
import os
import sys
from typing import Union

import numpy as np

import gurobipy as gp
from gurobipy import GRB
import itertools
import random
from random import randrange
import copy
import matplotlib.pyplot as plt
import mapel
import os
import multiprocessing
from functools import partial
import tikzplotlib
from random import shuffle
import math
import itertools
import networkx as nx

import mapel.elections.models.sampling.samplemat as samp

try:
    import pulp
except Exception:
    pulp = None

try:
    sys.path.append('/Users/szufa/PycharmProjects/abcvoting/')
    from abcvoting import abcrules, preferences
except ImportError:
    abcrules = None
    preferences = None

from mapel.main._glossary import *
from mapel.elections.metrics import lp
from mapel.elections.other import winners2 as win


# MAIN FUNCTIONS
def highest_borda_score(election) -> int:
    """ Compute highest BORDA score of a given election """
    c = election.num_candidates
    vectors = election.get_vectors()
    borda = [sum([vectors[i][pos] * (c - pos - 1) for pos in range(c)])
             for i in range(c)]
    return max(borda) * election.num_voters


def highest_plurality_score(election) -> int:
    """ compute highest PLURALITY score of a given election"""
    first_pos = election.get_matrix()[0]
    return max(first_pos) * election.num_voters


def highest_copeland_score(election) -> Union[int, str]:
    """ compute highest COPELAND score of a given election """
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'

    election.compute_potes()
    scores = np.zeros([election.num_candidates])

    for i in range(election.num_candidates):
        for j in range(i + 1, election.num_candidates):
            result = 0
            for k in range(election.num_voters):
                if election.potes[k][i] < election.potes[k][j]:
                    result += 1
            if result > election.num_voters / 2:
                scores[i] += 1
            elif result < election.num_voters / 2:
                scores[j] += 1
            else:
                scores[i] += 0.5
                scores[j] += 0.5

    return max(scores)


def lowest_dodgson_score(election):
    """ compute lowest DODGSON score of a given election """
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None', 'None'

    min_score = math.inf

    for target_id in range(election.num_candidates):

        # PREPARE N
        unique_potes, N = _potes_to_unique_potes(election.potes)

        e = np.zeros([len(N), election.num_candidates,
                      election.num_candidates])

        # PREPARE e
        for i, p in enumerate(unique_potes):
            for j in range(election.num_candidates):
                for k in range(election.num_candidates):
                    if p[target_id] <= p[k] + j:
                        e[i][j][k] = 1

        # PREPARE D
        D = [0 for _ in range(election.num_candidates)]
        threshold = math.ceil((election.num_voters + 1) / 2.)
        for k in range(election.num_candidates):
            diff = 0
            for i, p in enumerate(unique_potes):
                if p[target_id] < p[k]:
                    diff += N[i]
                if diff >= threshold:
                    D[k] = 0
                else:
                    D[k] = threshold - diff
        D[target_id] = 0  # always winning

        # file_name = f'{np.random.random()}.lp'
        # file_name = 'tmp_old.lp'
        # path = os.path.join(os.getcwd(), "trash", file_name)
        # lp.generate_lp_file_dodgson_score_old(path, N=N, e=e, D=D)
        # score, total_time = lp.solve_lp_dodgson_score(path)
        # lp.remove_lp_file(path)

        score = lp.solve_lp_file_dodgson_score(election, N=N, e=e, D=D)

        # if election.election_id == 'Impartial Culture_2' and target_id == 0:
        #     exit()

        if score < min_score:
            min_score = score

    print(min_score)
    return min_score, 0


def highest_cc_score(election, feature_params):
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None', 'None'
    winners, total_time = win.generate_winners(election=election,
                                               num_winners=feature_params['committee_size'],
                                               ballot="ordinal",
                                               type='borda_owa', name='cc')
    return get_cc_score(election, winners)


def highest_hb_score(election, feature_params):
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None', 'None'
    winners, total_time = win.generate_winners(election=election,
                                               num_winners=feature_params['committee_size'],
                                               ballot="ordinal",
                                               type='borda_owa', name='hb')
    return get_hb_score(election, winners), get_hb_dissat(election, winners)


def highest_pav_score(election, feature_params):
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None', 'None'
    winners, total_time = win.generate_winners(election=election,
                                               num_winners=feature_params['committee_size'],
                                               ballot="ordinal",
                                               type='bloc_owa', name='hb')
    return get_pav_score(election, winners), get_pav_dissat(election, winners)


# HELPER FUNCTIONS
def _potes_to_unique_potes(potes):
    """ Remove repetitions from potes (positional votes) """
    unique_potes = []
    n = []
    for pote in potes:
        flag_new = True
        for i, p in enumerate(unique_potes):
            if list(pote) == list(p):
                n[i] += 1
                flag_new = False
        if flag_new:
            unique_potes.append(pote)
            n.append(1)
    return unique_potes, n


# GET SCORE
def get_score(election, winners, rule) -> float:
    if rule == 'cc':
        return get_cc_score(election, winners)
    elif rule == 'hb':
        return get_hb_score(election, winners)
    elif rule == 'pav':
        return get_pav_score(election, winners)


def get_cc_score(election, winners) -> float:
    num_voters = election.num_voters
    num_candidates = election.num_candidates
    votes = election.votes

    score = 0

    for i in range(num_voters):
        for j in range(num_candidates):
            if votes[i][j] in winners:
                score += num_candidates - j - 1
                break

    return score


def get_hb_score(election, winners) -> float:
    num_voters = election.num_voters
    num_candidates = election.num_candidates
    votes = election.votes

    score = 0

    for i in range(num_voters):
        ctr = 1.
        for j in range(num_candidates):
            if votes[i][j] in winners:
                score += (1. / ctr) * (num_candidates - j - 1)
                ctr += 1

    return score


def get_pav_score(election, winners) -> float:
    num_voters = election.num_voters
    num_candidates = election.num_candidates
    votes = election.votes

    score = 0

    vector = [0.] * num_candidates
    for i in range(len(winners)):
        vector[i] = 1.

    for i in range(num_voters):
        ctr = 1.
        for j in range(num_candidates):
            if votes[i][j] in winners:
                score += (1. / ctr) * vector[j]
                ctr += 1

    return score


def get_hb_dissat(election, winners) -> float:
    num_voters = election.num_voters
    num_candidates = election.num_candidates

    dissat = 0

    for i in range(num_voters):
        ctr = 1.
        for j in range(num_candidates):
            if election.votes[i][j] in winners:
                dissat += (1. / ctr) * (j)
                ctr += 1

    return dissat


def get_pav_dissat(election, winners) -> float:
    num_voters = election.num_voters
    num_candidates = election.num_candidates

    dissat = 0

    vector = [0. for _ in range(100)]
    for i in range(10, 100):
        vector[i] = 1.

    for i in range(num_voters):
        ctr = 1.
        for j in range(num_candidates):
            if election.votes[i][j] in winners:
                dissat += ((1. / ctr) * vector[j])
                ctr += 1

    return dissat


##########################################################################################################################################################

def condorcet_winner(election) -> Union[int, str]:
    """ compute highest COPELAND score of a given election """
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'

    election.compute_potes()
    scores = np.zeros([election.num_candidates])

    for i in range(election.num_candidates):
        for j in range(i + 1, election.num_candidates):
            result = 0
            for k in range(election.num_voters):
                if election.potes[k][i] < election.potes[k][j]:
                    result += 1
            if result > election.num_voters / 2:
                scores[i] += 1
            elif result < election.num_voters / 2:
                scores[j] += 1
            else:
                scores[i] += 0.5
                scores[j] += 0.5
    if max(scores) == election.num_candidates - 1:
        return 1
    else:
        return 0


def condorcet_winner_number(election) -> Union[int, str]:
    """ compute highest COPELAND score of a given election """
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'
    print(election.election_id)
    election.compute_potes()
    pos_matrix = position_matrix(election.votes, election.num_candidates)
    return num_condorcet(pos_matrix, election.num_voters, election.num_candidates)


def condorcet_condition_violations(election) -> Union[int, str]:
    """ compute highest COPELAND score of a given election """
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'
    print(election.election_id)
    pos_matrix = position_matrix(election.votes, election.num_candidates)
    return condition_violations(pos_matrix, election.num_voters, election.num_candidates)


def can_be_caterpillar(election) -> Union[int, str]:
    """ compute highest COPELAND score of a given election """
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'
    print(election.election_id)
    election.compute_potes()
    pos_matrix = position_matrix(election.potes, election.num_candidates)
    return run_experiment_gs_cater(pos_matrix, election.num_voters, election.num_candidates, False)


def can_be_single_peaked(election) -> Union[int, str]:
    """ compute highest COPELAND score of a given election """
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'
    print(election.election_id)
    election.compute_potes()
    pos_matrix = position_matrix(election.potes, election.num_candidates)
    return run_experiment_gs_cater(pos_matrix, election.num_voters, election.num_candidates, True)

def can_be_balanced(election)-> Union[int, str]:
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'
    print(election.election_id)
    election.compute_potes()
    pos_matrix = position_matrix(election.potes, election.num_candidates)
    return run_experiment_gs_balanced(pos_matrix, election.num_candidates)

def max_swap_distance_sampled(election)-> Union[int, str]:
    if election.model_id in LIST_OF_FAKE_MODELS:
        return 'None'
    it=100
    #print(election.model_id)
    print(election.election_id)
    election.compute_potes()
    pos_matrix = position_matrix(election.votes, election.num_candidates)
    return run_experiment_max_swap_distance_sampled(election,pos_matrix, election.num_candidates, election.num_voters,it)

def run_experiment_max_swap_distance_sampled(election,x,m,n,it):
    max_value=0
    avg_value=0
    for i in range(it):
        election1 = samp.sample_election_using_permanent(x)
        election2 = samp.sample_election_using_permanent(x)
        with open('./trash/'+str(election.election_id).replace(" ", "_")+'1.txt', 'w') as f:
            for vote in election1:
                f.write(','.join(str(e) for e in vote)+'\n')
        f.close()
        with open('./trash/'+str(election.election_id).replace(" ", "_")+'2.txt', 'w') as f:
            for vote in election2:
                f.write(','.join(str(e) for e in vote)+'\n')
        f.close()
        cmd = "./computedis.out "+" "+str(m)+" "+str(n)+" "+'./trash/'+str(election.election_id).replace(" ", "_")+'1.txt'+" "+'./trash/'+str(election.election_id).replace(" ", "_")+'2.txt'+" "+'./trash/'+str(election.election_id).replace(" ", "_")+'res.txt'
        #print(cmd)
        os.system(cmd)  # returns the exit code in unix

        with open('./trash/'+str(election.election_id).replace(" ", "_")+'res.txt') as f:
            first_line = f.readline()
        returned_value=int(first_line)
        #print(returned_value)
        if returned_value>max_value:
            max_value=returned_value
        avg_value+=returned_value/it
    diam=0.25*n*(m*m-m)
    return avg_value/diam
        #print(returned_value)


def run_experiment_gs_balanced(x, m):
    #print(x)
    half_m=int(m/2)
    if m==1:
        return True
    possible_sibilings=[]
    for i in range(m):
        for j in range(i+1,m):
            possible_sibilings.append((i,j))
    for i in range(half_m):
        for pair in possible_sibilings:
            if not (x[2*i][pair[0]]==x[2*i+1][pair[1]] and x[2*i][pair[0]]==x[2*i+1][pair[1]]):
                possible_sibilings.remove(pair)
    G = nx.Graph()
    G.add_nodes_from(list(range(m)))
    G.add_edges_from(possible_sibilings)
    #print(G)
    matching=list(sorted(nx.max_weight_matching(G)))
    #print(matching)
    if len(matching)==m/2:
        Y=[[0 for _ in range(half_m)] for _ in range(half_m)]
        for i in range(half_m):
            for j in range(half_m):
                Y[i][j]=x[2*i][matching[j][0]]+x[2*i][matching[j][1]]
        return run_experiment_gs_balanced(Y, half_m)
    else:
        return False

def single_peaked_possible(posM,m,single_peaked):
    posM_transp = [[0 for _ in range(m)] for _ in range(m)]
    for i in range(m):
        for j in range(m):
            posM_transp[i][j] = posM[j][m-i-1]
    posM = posM_transp

    for i in range(m):
        for j in range(m-i,i):
            #print(i,j)
            if posM[i][j]>0:
                return False
    return True

def run_experiment_gs_cater(posM, n, m, single_peaked):
    #print(posM)
    for i in range(m):
        for j in range(m):
            posM[i][j] = posM[i][j] / n

        # print(posM)
    for perm in itertools.permutations(range(m)):
        # print(perm)
        posM_perm = [[0 for _ in range(m)] for _ in range(m)]
        for i in range(m):
            for j in range(m):
                posM_perm[i][j]=posM[i][perm[j]]
        posM_transp = [[0 for _ in range(m)] for _ in range(m)]
        if single_peaked:
            for i in range(m):
                for j in range(m):
                    posM_transp[j][m-i-1] = posM_perm[i][j]
            posM_perm = posM_transp

        if single_peaked_possible(posM_perm,m,single_peaked):
            if realization_caterpillar(posM_perm, m):
                #print(posM_perm)
            #print("sdfsdfsd")
                return True
    return False


def condition_violations(A, n, m):
    # print(A)
    count = 0
    for c in range(m):
        can_be_condorcet = condorcet_cand(A, n, m, c)
        if can_be_condorcet != check_cond_condition(A, c, n, m):
            count += 1
    return count


def check_cond_condition(A, c, n, m):
    for i in range(1, m + 1):
        candidate_values = [0 for _ in range(m)]
        # print("I",i)
        for j in range(m):
            if j != c:
                c_val = 0
                for k in range(1, i + 1):
                    c_val += A[j][k - 1]
                # print("VALUE ", c_val, j)
                candidate_values[j] = max(0, c_val - int((n - 1) / 2))
        # print("CAND ", candidate_values)
        for s in range(1, m):
            # print("Size", s)
            cand_ids = list(range(m))
            sort_cand_ids = [x for _, x in reversed(sorted(zip(candidate_values, cand_ids)))]
            # print(sort_cand_ids)
            # print(candidate_values)
            # exit()
            left_side = 0
            for q in range(s):
                left_side += candidate_values[sort_cand_ids[q]]
            # print("LEFT SIDE", left_side)
            right_side = 0
            for p in range(1, i):
                right_side += min(s, i - p) * A[c][p - 1]
            if left_side > right_side:
                return False
    # print("RS",right_side)
    return True


def position_matrix(election, m):
    #print(election)
    pos = [[0 for i in range(m)] for j in range(m)]
    for e in election:
        for i in range(m):
            pos[e[i]][i] = pos[e[i]][i] + 1

    #print(pos)
    #exit(0)
    return pos


# Assume that in A each row represents a candidate, each column a position
def condorcet_cand(A, n, m, c):
    # print(A)
    mm = gp.Model("mip1")
    mm.setParam('OutputFlag', False)
    # x[i,j,k] is candidate i assigned to position j in vote k
    x = mm.addVars(m, m, n, vtype=GRB.BINARY)

    # pos_c[i] position of candidate c in vote i
    pos_c = []
    for i in range(m):
        for j in range(A[c][i]):
            pos_c.append(i)

    # print(pos_c)
    for i in range(n):
        mm.addConstr(x[c, pos_c[i], i] == 1)

    # Every position in all votes is filled exactly once
    for k in range(n):
        for j in range(m):
            mm.addConstr(gp.quicksum(x[i, j, k] for i in range(m)) == 1)

    # Every candidate is only assigned once in each vote
    for k in range(n):
        for i in range(m):
            mm.addConstr(gp.quicksum(x[i, j, k] for j in range(m)) == 1)

    # For every candidate, the position vector is matched
    for i in range(m):
        for j in range(m):
            mm.addConstr(gp.quicksum(x[i, j, k] for k in range(n)) == A[i][j])

    # Enforce that for each candidate that it loses pairwise majority vote against c
    for i in range(m):
        if not i == c:
            if n % 2 == 0:
                mm.addConstr(gp.quicksum(x[i, j, k] for k in range(n) for j in range(pos_c[k])) <= int(n / 2) - 1)
            else:
                mm.addConstr(gp.quicksum(x[i, j, k] for k in range(n) for j in range(pos_c[k])) <= int(n / 2))
    mm.optimize()

    if mm.status == GRB.Status.INFEASIBLE:
        mm.computeIIS()
        mm.write("model.ilp")
        # print("INNNFF")
        return False
    else:
        election = []
        for k in range(n):
            vote = []
            for j in range(m):
                for i in range(m):
                    if x[i, j, k].X >= 0.99:
                        vote.append(i)
            election.append(vote)
        # print(election)
        if not check_condorcetWinner(election, m):
            exit()
        return True


def condorcet(A, n, m):
    for c in range(m):
        if condorcet_cand(A, n, m, c):
            return True
    else:
        return False


def num_condorcet(A, n, m):
    # print(A)
    global disagree
    count = 0
    for c in range(m):
        can_be_condorcet = condorcet_cand(A, n, m, c)
        if can_be_condorcet:
            count += 1
    # condition=check_cond_condition(A,c,n,m)
    # if condition!=can_be_condorcet:
    #	print("ERRR")
    # disagree+=1
    #	print(disagree)
    return count


def check_condorcetWinner(election, m):
    pairwise = [[0 for x in range(m)] for y in range(m)]
    for v in election:
        # print(v)
        for c in range(m):
            for cc in range(c + 1, m):
                if v.index(c) < v.index(cc):
                    pairwise[c][cc] = pairwise[c][cc] + 1
                    pairwise[cc][c] = pairwise[cc][c] - 1
                else:
                    pairwise[c][cc] = pairwise[c][cc] - 1
                    pairwise[cc][c] = pairwise[cc][c] + 1

    # print(pairwise)
    for c in range(m):
        winner = True
        for cc in range(m):
            if pairwise[c][cc] <= 0 and not c == cc:
                winner = False
        if winner:
            return True
    return False


def realization_caterpillar(x, m):
    #print("START")
    # print(A)
    mm = gp.Model("mip1")
    mm.setParam('OutputFlag', False)
    l = mm.addVars(6 * m, 6 * m, vtype=GRB.CONTINUOUS, lb=0)
    r = mm.addVars(6 * m, 6 * m, vtype=GRB.CONTINUOUS, lb=0)

    for i in range(2 * m):
        for j in range(6 * m):
            mm.addConstr(l[i, j] == 0)
            mm.addConstr(r[i, j] == 0)
    for i in range(6 * m):
        for j in range(2 * m):
            mm.addConstr(l[i, j] == 0)
            mm.addConstr(r[i, j] == 0)

    for i in range(3 * m, 6 * m):
        for j in range(6 * m):
            mm.addConstr(l[i, j] == 0)
            mm.addConstr(r[i, j] == 0)

    for i in range(6 * m):
        for j in range(3 * m, 6 * m):
            mm.addConstr(l[i, j] == 0)
            mm.addConstr(r[i, j] == 0)

    for i in range(2 * m, 3 * m):
        for j in range(2 * m, 3 * m):
            mm.addConstr(l[i, j] + r[i, j] == x[i - 2 * m][j - 2 * m])

    for j in range(1, m):
        for i in range(-m, m + 1):
            mm.addConstr(l[i - 2 + 2 * m, j - 1 + 2 * m] + r[i + m - j - 1 + 2 * m, j - 1 + 2 * m] == l[
                i - 1 + 2 * m, j + 2 * m] + r[i + m - j - 2 + 2 * m, j + 2 * m])

    mm.optimize()
    #print("END")
    if mm.status == GRB.Status.INFEASIBLE:
        #print("END")
        return False
    else:
        print(x)
        return True
