import mapel
import os
import random


if __name__ == "__main__":
    exp_id='8x80'
    experiment = mapel.prepare_experiment(experiment_id=exp_id,embedding_id='spring')


    ############ Section 2 ############
    #Figure1
    experiment.print_map(textual=["UN", "ID"], textual_size=10, legend=False, saveas=exp_id, shading=True)

    ############ Section 3 ############
    #Section 3.3 (Figure 2a)
    random.seed(0)
    f_id = 'max_swap_distance_sampled'
    experiment.compute_feature(feature_id=f_id)
    experiment.print_map(feature_id=f_id, saveas=f_id + "_" + exp_id, textual=["UN", "ID"], textual_size=17,
                         legend=False, rounding=2)
    #exit()

    ############ Section 4 ############
    #"An Experiment"
    # Results can be found in experiments/8x80/features

    f_id='can_be_single_peaked'
    experiment.compute_feature(feature_id=f_id)


    f_id='can_be_caterpillar'
    experiment.compute_feature(feature_id=f_id)

    f_id='can_be_balanced'
    experiment.compute_feature(feature_id=f_id)


    ############ Section 5 ############

    #Experiment 1 Results can be found in experiments/8x80/features
    f_id='condorcet_condition_violations'
    experiment.compute_feature(feature_id=f_id)



    #Figure2b
    num_colors = 6
    f_id = 'condorcet_winner_number'
    experiment.compute_feature(feature_id=f_id)
    experiment.print_map(feature_id=f_id, saveas=f_id + "_" + exp_id, textual=["UN", "ID"], textual_size=17,
                         legend=False, rounding=0, xticklabels=[str(q) for q in range(num_colors)],
                         ticks_pos=[(2 * q + 1) / num_colors / 2 for q in range(num_colors)])
