#!/usr/bin/env python
import sys
import os
import itertools
import copy
import argparse

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(os.path.join(os.path.dirname(SCRIPT_DIR)))

import mapel
import mapel.elections.models.sampling.samplemat as smpl

def get_args_parser():
  ap = argparse.ArgumentParser()
  ap.add_argument("-ie", "--input_mapel_experiment", required = True,
  help="Input mapel experiment, already initialized!")
  return ap

if __name__ == '__main__':
  args = get_args_parser().parse_args()
  exp_name = args.input_mapel_experiment

  experiment = mapel.prepare_experiment(experiment_id = exp_name, embedding_id="spring")

  experiment.compute_feature(feature_id='all_realizations_count')
