#!/usr/bin/env python
import argparse
import csv
import os

def get_args_parser():
  ap = argparse.ArgumentParser()
  ap.add_argument("-if", "--input_feature_file", required = True,
  help="Input feature file of feature: avg_swap_dist_of_realizations")
  ap.add_argument("-sf", "--scaling_factor", type = float, default = 1.0,
  help="Possible scaling factor for values")
  return ap

if __name__ == '__main__':
  args = get_args_parser().parse_args()
  feat_filepath = args.input_feature_file
  scaling_factor = args.scaling_factor

  data = None
  with open(feat_filepath, "r") as ff:
    data = csv.reader(ff, delimiter = ";", dialect = csv.unix_dialect)
    data = list(data)

  tuple_elem_to_filename_part = {
    0: "max",
    1: "min",
    2: "avg",
  }

  def get_filename(filename_part):
    dirr = os.path.dirname(feat_filepath)
    return os.path.join(dirr, "manual_" + filename_part + \
    "_swap_dist_of_realizations.csv")

  for elem, filename_part in tuple_elem_to_filename_part.items():
    print(f"Writing: {filename_part}")
    header = data[0]
    with open(get_filename(filename_part), "w") as outfile:
      writer = csv.DictWriter(outfile, delimiter = ";", dialect =
      csv.unix_dialect, fieldnames = data[0], quoting = csv.QUOTE_NONE)
      writer.writeheader()
      for entry in data[1:]:
        row = entry[:]
        if row[1] != "":
          if row[1] == '0':
            row[1] = 0
          else:
            row[1] = (eval(row[1])[elem])/scaling_factor
        else:
          row[1] = None
        writer.writerow({header[i]: row[i] for i in range(len(row))})
      
    
