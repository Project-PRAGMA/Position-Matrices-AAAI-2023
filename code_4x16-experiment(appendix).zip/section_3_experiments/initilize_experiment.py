#!/usr/bin/env python

import sys
import os
import itertools
import copy

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
print(os.path.join(os.path.dirname(SCRIPT_DIR), 'mapel'))
sys.path.append(os.path.join(os.path.dirname(SCRIPT_DIR)))

import mapel
import mapel.elections.models.sampling.samplemat as smpl
import tqdm

import numpy as np
import gurobipy as gb


import core.sampler as smp



def build_perms(matrix):
  '''
  Returns all matchings feasible for a given matrix
  '''
  #print_matrix(matrix)
  if len(matrix[0]) == 0:
    #print("EMPTY")
    #exit(1)
    return [[]]
  perms = []
  last_col = []
  for j in range(len(matrix)):
    last_col.append(matrix[j].pop())
  if sum(last_col) > 0:
    for last_cand, elig in enumerate(last_col):
      if elig <= 0:
        continue
      zeroed_vector = matrix[last_cand][:]
      matrix[last_cand][:]  = len(matrix[last_cand])*[0]
      for perm in build_perms(matrix):
        perms.append(perm + [last_cand])
      matrix[last_cand][:] = zeroed_vector[:]
  for j in range(len(matrix)):
    matrix[j].append(last_col[j])
  return perms

def build_elections(matrix):
  def inner(matrix, elections):
    if sum(matrix[0]) == 0:
      return [elections]
    perms = build_perms(matrix)
    all_elections = []
    print(len(perms))
    for vote in perms:
      for pos, cand in enumerate(vote):
        matrix[cand][pos] -= 1
      all_elections += inner(matrix, elections + [vote])
      for pos, cand in enumerate(vote):
        matrix[cand][pos] += 1
    return all_elections
  return inner(matrix, [])
  
def build_elections_automata(matrix):
  assert type(matrix) == list
  assert len(matrix) > 0

  votes_map = {i: perm for i, perm in
  enumerate(itertools.permutations(range(len(matrix[0]))))}

###  def inner(matrix, elections, acc, rem_votes, pos):
###    print(rem_votes)
###    if rem_votes == 0:
###      acc.add(tuple(elections))
###    if pos >= len(votes_map):
###      return
###    #self loop on this position
###    vote = votes_map[pos]
###    illegal = False
###    for pos, cand in enumerate(vote):
###      matrix[cand][pos] -= 1
###      if (not illegal) and matrix[cand][pos] < 0:
###        illegal = True
###    if illegal == False:
###      inner(matrix, elections + [pos], acc, rem_votes - 1, pos)
###    for pos, cand in enumerate(vote):
###      matrix[cand][pos] += 1
###    #skip this position
###    inner(matrix, elections, acc, rem_votes, pos + 1)
###
###  acc = set()
###  inner(matrix, [], acc, sum(matrix[0]), 0)

  acc = set()
  queue = [(matrix, [], sum(matrix[0]), 0)]
  counter = 0
  print(len(votes_map))
  while queue:
    #print(counter)
    counter = counter + 1
    if counter == 1000:
      print(len(queue))
      counter = 0
    print(len(queue))
    c_matrix, c_elections, c_rem_votes, c_pos = queue.pop()
    print(len(queue))
    if c_rem_votes == 0:
      acc.add(tuple(c_elections))
    if c_pos >= len(votes_map):
      return

    #skip this position
    queue.append((c_matrix, c_elections, c_rem_votes, c_pos + 1))

    #take this position
    vote = votes_map[c_pos]
    illegal = False
    n_matrix = copy.deepcopy(matrix)
    for pos, cand in enumerate(vote):
      n_matrix[cand][pos] -= 1
      if n_matrix[cand][pos] < 0:
        illegal = True
        continue
    if illegal == False:
      queue.append((n_matrix, c_elections + [c_pos], c_rem_votes - 1, c_pos))

  return acc

def all_elections_gurobi(matrix):
  assert type(matrix) == list
  assert len(matrix) > 0

  print(matrix)
  votes_map = {i: perm for i, perm in
  enumerate(itertools.permutations(range(len(matrix[0]))))}
  pref_count = len(votes_map)

  model = gb.Model("Election realizing matrix")
  model.setParam('OutputFlag', False)
  x = model.addVars(pref_count, lb=0, vtype=gb.GRB.INTEGER, name="x")

  for cand in range(len(matrix)):
    for pos in range(len(matrix[cand])):
      model.addConstr(gb.quicksum(
      x[vote] * (1 if votes_map[vote][pos] == cand else 0)
      for vote in range(pref_count)
      ) == matrix[cand][pos])

  solutions_chunk = 2000000000
  model.setParam(gb.GRB.Param.PoolSearchMode, 2)
  model.setParam(gb.GRB.Param.PoolSolutions, solutions_chunk)
  model.setParam(gb.GRB.Param.PoolGap, 0)
  model.setParam(gb.GRB.Param.MIPGap, 0)

  continue_computing = True

  solutions = []
  try:
    while continue_computing:
      model.update()
      model.optimize()
      if not model.Status == gb.GRB.OPTIMAL:
        print(f"No more solutions")
        break
      for sol_number in range(model.SolCount):
        election = []
        model.Params.SolutionNumber = sol_number
        for pref_nr in range(pref_count):
          pref_var = model.getVarByName("{}[{}]".format("x", pref_nr))
          nr_of_prefs = int(round(pref_var.Xn,0))
          if nr_of_prefs >= 1:
            election.append((pref_nr, nr_of_prefs))
        election = tuple(election)
        solutions.append(election)
        #cov_var = m.getVarByName(COVERAGE_VARIABLE_NAME)
        #app_var = m.getVarByName(APPROVAL_VARIABLE_NAME)
        #solutions.append ((int(m.poolObjVal), int(round(cov_var.Xn,0)),
        #int(round(app_var.Xn,0)), committee))
      continue_computing = (model.solCount == solutions_chunk)
      #print(model.solCount)
      #print(solutions_chunk)
      #print(continue_computing)
      
      #for solution in solutions:
      #  #logger.info(f"yielding: {solution}")
      #  yield (True, solution)
      #for _, _, _, forbidden_committee in solutions:
      #  m.addConstr(quicksum(m.getVarByName("{}[{}]".format(CANDIDATE_VARIABLE_NAME,
      #  cand_id)) for cand_id in forbidden_committee) <= ((just_group_size if
      #  just_group_size is not None else committeeSize) - 1))
      if continue_computing:
        print(f"Computing next solution pool")
  except gb.GurobiError as e:
    print(f'Error reported: {e}')
  #logger.info("Finishing")

  return solutions, votes_map

def compute_all_sister_election(election):
  assert not (election.votes is None)
#  if election.votes is None:
#    print(election.election_id)
#    return
  matrix = smp.get_matrix(election)
  return all_elections_gurobi(matrix)

def initialize_experiment(experiment):
  experiment.prepare_elections()
  experiment.prepare_matrices()
  experiment.compute_distances()
  experiment.embed("spring")

def count_all_sister_election(election):
  elections, preferences_map = compute_all_sister_election(election)
  return len(elections)

def single_election_experiment(model_id, params, num_voters, num_candidates):
  election = mapel.generate_election(model_id ='norm-mallows', params =
  {'norm-phi': 0.1}, num_voters = 20, num_candidates = 6)
  return count_all_sister_election(election)

def single_election_experiment_mallows(phi, vtrs_count, cnds_count):
  return single_election_experiment('norm-mallows', {'norm-phi': phi}, vtrs_count,
  cnds_count)


if __name__ == '__main__':
  experiment = \
  mapel.prepare_experiment(experiment_id='4x4', embedding_id = 'spring')

  initialize_experiment(experiment)
  experiment.print_map()
  print("done")
