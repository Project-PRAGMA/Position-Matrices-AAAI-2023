We assume one wants to repeat our experiment. So, let <exp_name> always refer to
    4x16_unitialized.

If one wants to run their own experiment, then one should get familiar with the
library mapel.

0. Install all dependencies listed in requirements.txt (using pip) and go to directory
      section_3_experiments
1. Run
      initilize_experiment.py
  previously changing variable experiment_id in initialize_experiment.py file to <exp_name>.
  This will intialize the elections in our experiment.
2. Run
      all_elcs_mapel.py -ie <exp-name>
   to compute all elections realizing the position matrices of of elections in
   our experiment.
3. Run
     ./realiz_swap_mapel_all_realizations_count.py -ie 4x4
   to compute a feature representing the number of realizations for all
   matrices in our experiment.
4. Run
      ./realiz_swap_mapel_realizing_distances.py -ie 4x4
   to compute statistics of distances between all realizations of the matrices
   in our experiment---each matrix gets a statistics between (only) their
   realizations.
5. Run
     ./realiz_swap_mapel_feature_separation.py -if
     experiments/4x4/features/avg_swap_dist_of_realizations.csv  -r <ratio>
   to prepare the statistics from point 4 to present in mapel. Parameter
   <ratio>, by default 1.0, allows to divide each distance in the statistics by
   <ratio>. This is useful to show the distance as a percentage of maximum
   possible distance.
6. Run
     ./realiz_swap_mapel_visualize.py -ie 4x4
   which will produce 4 maps, with the number of realizations and min/avg/max
   distance between all realizations of a single matrix, in directory
     images

     


