import numpy as np
import guardians_plus as gp

#matr_usual = [[2,2,2], [2,2,2], [2,2,2]]
#matr_numpy = np.ones((7,7))
#print(samplemat.sample_election_using_permanent(matr_usual))
#print(samplemat.sample_election_using_permanent(matr_numpy))

print(gp.generate_un_from_matrix_votes(10, 10))
