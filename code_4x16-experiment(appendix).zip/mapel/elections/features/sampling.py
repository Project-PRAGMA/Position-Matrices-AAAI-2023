from .other import is_condorcet
from ..models.sampling.samplemat import sample_election_using_permanent
from ..models.sampling.samplemat import sample_election_using_permanent
import os
import multiprocessing as mproc
import signal
import sys

import pycomputedist

def condorcet_frequency_of_samples(election, feature_params):
  if not election.votes:
    return None
  from ..objects import OrdinalElection
  sample_size = feature_params['sample_size']
  cw_winners_counter = 0
  for s in range(sample_size):
    matrix = election.get_position_matrix()
    matrix = matrix.astype('int')
    new_votes = sample_election_using_permanent(matrix)
    new_election = OrdinalElection.OrdinalElection("exid", "elid", votes =
    new_votes, num_voters = election.num_voters, num_candidates = election.num_candidates)
    new_election.compute_potes()
    cw_winners_counter += is_condorcet(new_election)
  return cw_winners_counter/sample_size

def number_of_realizations(election, feature_params = None):
  if not election.votes:
    return None
  def read_in_all_elections(filename):
    _, data = read_data(filename)  
    return data["all realizations"], data["id to preferences"]
  cwd = os.getcwd()
  all_real_dir = "all_realizations"
  all_real_path = os.path.join(cwd, "experiments", election.experiment_id, all_real_dir) 
  filepath = os.path.join(all_real_path, election.election_id + ".alle")
  all_el, id2pref = read_in_all_elections(filepath)
  import math
  return math.log(len(all_el), 10)
  
def avg_swap_distance_of_realizations(election, feature_params = None):
  from ..objects import OrdinalElection, OrdinalElectionExperiment
  if not election.votes:
    return None

  def read_in_all_elections(filename):
    _, data = read_data(filename)  
    return data["all realizations"], data["id to preferences"]

  def translated_elections(realizations, id2prefs):
    for realization in realizations:
      yield [id2prefs[str(vote_id)] for vote_id in realization]
    
  cwd = os.getcwd()
  all_real_dir = "all_realizations"
  all_real_path = os.path.join(cwd, "experiments", election.experiment_id, all_real_dir) 
  filepath = os.path.join(all_real_path, election.election_id + ".alle")
  all_el, id2pref = read_in_all_elections(filepath)

  print(election.election_id)

  mapel_elects = []
  for profile in translated_elections(all_el, id2pref):
    election = OrdinalElection.OrdinalElection("test_exp", "test_el_1", votes =  profile,
    num_voters = len(profile), num_candidates = max(profile[0]) + 1, label =
    f"t10")
    mapel_elects.append(election)
  
  if len(mapel_elects) == 1:
    return 0


  lock = mproc.Lock()
  poolsize = mproc.cpu_count()

  original_sigint_handler = signal.signal(signal.SIGINT, signal.SIG_IGN)

  pool = mproc.Pool(processes=poolsize, initializer=initializer())
  
  print(f"Processes: {poolsize}")

  def terminatepool(*args, **kwargs):
    pool.terminate()
    exit(1)

  if sys.platform == "win32":
     import win32api
     win32api.setconsolectrlhandler(terminatepool, true)
  else:
     signal.signal(signal.SIGINT, terminatepool)

  mapel_elects = mapel_elects[:4]

  no_elections = len(mapel_elects)
  results = []

  print("batches: " + str(no_elections))

#  for i in range(no_elections):
#    for j in range(i + 1, no_elections):
#      results.append(compute_swap(mapel_elects[i], mapel_elects[j]))

  for i in range(no_elections):
    pool.apply_async(compute_swap_batch, (i, mapel_elects), {},
        lambda output, llock=lock, storage=results:
        safe_store_result_list(storage, output, llock),
        lambda exception: report_failure(exception))
 
  pool.close()
  pool.join()



  
##  results = []
##
##  for i in range(no_elections):
##    for j in range(i + 1, no_elections):
##      dist = compute_swap(mapel_elects[i], mapel_elects[j])
##      results.append(dist)


  avg = sum(results)/len(results)

  return (max(results), min(results), avg)


class initializer(object):
  def __call__(self, *args, **kwargs):
    if sys.platform == "win32":
      import win32api # ignoring the signal      
      win32api.setconsolectrlhandler(none, true)

  
def report_failure(exception):
  print(f"skipped due to {exception}")

def compute_swap_batch(i, elections):
  results = []
  for j in range(i + 1, len(elections)):
    results.append(compute_swap(elections[i], elections[j]))
  return results

def safe_store_result_list(storage, to_store, lock):
  lock.acquire()
  try:
    storage += to_store
  finally:
    lock.release()


def compute_swap(election1, election2):
## OLD TRADITIONAL WAY ##
##  elect_id = f"a_fake_id_{os.getpid()}"
##  m = election1.num_candidates
##  n = election1.num_voters
##
##  def no_space(name):
##    return str(name).replace(" ", "_")
##  with open('./trash/'+ no_space(elect_id) +'1.txt', 'w') as f:
##      for vote in election1.votes:
##          f.write(','.join(str(e) for e in vote)+'\n')
##  with open('./trash/'+ no_space(elect_id) +'2.txt', 'w') as f:
##      for vote in election2.votes:
##          f.write(','.join(str(e) for e in vote)+'\n')
##  cmd = "./computedis.out "+" "+str(m)+" "+str(n)+" "+'./trash/'+no_space(elect_id)+'1.txt'+" "+'./trash/'+no_space(elect_id)+'2.txt'+" "+'./trash/'+no_space(elect_id)+'res.txt'
##  #print(cmd)
##  os.system(cmd)  # returns the exit code in unix
##
##  result_path ='./trash/'+str(elect_id).replace(" ", "_")+'res.txt' 
##  with open(result_path) as f:
##      first_line = f.readline()
##  #os.remove(result_path)
##  swapd=int(first_line)
######################################

  swapd= pycomputedist.pycomputedist(election1.votes, election2.votes)
  return swapd

def get_matrix(election):
  '''
  Returns the position matrix X of the given election,
  where X[i][j] specifies how many times candidate i was
  on position j.
  '''
  matrix = [[0]*election.num_candidates for _ in range(election.num_candidates)]
  for vote in election.votes:
    for pos,c in enumerate(vote):
      matrix[c][pos] += 1
  return matrix

####### IO UTILS ########
def read_data(filename):
  SEC_SEPARATOR = "$$SEC$$" 
  import json
  with open(filename, "r") as infile:
    observed_section_break = False
    cumul_text = []
    for line in infile:
      if line.strip() == SEC_SEPARATOR:
        metadata = json.loads("".join(cumul_text))
        cumul_text = []
        continue
      cumul_text.append(line)
    data = json.loads("".join(cumul_text))
  return metadata, data
